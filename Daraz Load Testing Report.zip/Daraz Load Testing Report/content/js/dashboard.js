/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9618993135011442, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9944444444444445, 500, 1500, "Men shoes"], "isController": false}, {"data": [1.0, 500, 1500, "Kids toys"], "isController": false}, {"data": [1.0, 500, 1500, "Daraz woman clothing"], "isController": false}, {"data": [1.0, 500, 1500, "Baby toddler toys"], "isController": false}, {"data": [0.7166666666666667, 500, 1500, "Daraz home page"], "isController": false}, {"data": [1.0, 500, 1500, "Hair care"], "isController": false}, {"data": [1.0, 500, 1500, "Kids bag"], "isController": false}, {"data": [1.0, 500, 1500, "Men accessories"], "isController": false}, {"data": [1.0, 500, 1500, "Men bags"], "isController": false}, {"data": [1.0, 500, 1500, "Men eyewear"], "isController": false}, {"data": [1.0, 500, 1500, "Kids watches"], "isController": false}, {"data": [1.0, 500, 1500, "Men's Care"], "isController": false}, {"data": [1.0, 500, 1500, "Baby personal care"], "isController": false}, {"data": [1.0, 500, 1500, "Traditional game"], "isController": false}, {"data": [1.0, 500, 1500, "Daraz woman bags"], "isController": false}, {"data": [0.6666666666666666, 500, 1500, "Login"], "isController": false}, {"data": [0.7222222222222222, 500, 1500, "User profile"], "isController": false}, {"data": [1.0, 500, 1500, "Maternity care"], "isController": false}, {"data": [1.0, 500, 1500, "Sunglasses"], "isController": false}, {"data": [0.9555555555555556, 500, 1500, "Add to Cart-1"], "isController": false}, {"data": [0.9277777777777778, 500, 1500, "Add to Cart-0"], "isController": false}, {"data": [0.0, 500, 1500, "User profile-1"], "isController": false}, {"data": [1.0, 500, 1500, "Mens jewellery"], "isController": false}, {"data": [1.0, 500, 1500, "User profile-0"], "isController": false}, {"data": [1.0, 500, 1500, "Baby feeding"], "isController": false}, {"data": [1.0, 500, 1500, "Men watches"], "isController": false}, {"data": [1.0, 500, 1500, "Daraz woman western wear"], "isController": false}, {"data": [0.9944444444444445, 500, 1500, "Women jewellery"], "isController": false}, {"data": [1.0, 500, 1500, "Personal Care"], "isController": false}, {"data": [1.0, 500, 1500, "Luggage bag"], "isController": false}, {"data": [1.0, 500, 1500, "Men clothing"], "isController": false}, {"data": [1.0, 500, 1500, "Remote control toys and vehicles"], "isController": false}, {"data": [1.0, 500, 1500, "Women makeup"], "isController": false}, {"data": [0.9944444444444445, 500, 1500, "Laptop bag"], "isController": false}, {"data": [1.0, 500, 1500, "Skin care"], "isController": false}, {"data": [1.0, 500, 1500, "Travels"], "isController": false}, {"data": [1.0, 500, 1500, "Baby nursery"], "isController": false}, {"data": [1.0, 500, 1500, "Beauty Tools"], "isController": false}, {"data": [1.0, 500, 1500, "Bath & Body"], "isController": false}, {"data": [0.8222222222222222, 500, 1500, "Add to Cart"], "isController": false}, {"data": [0.9944444444444445, 500, 1500, "Daraz woman watches"], "isController": false}, {"data": [1.0, 500, 1500, "Men muslim wear"], "isController": false}, {"data": [1.0, 500, 1500, "Daraz woman shoes"], "isController": false}, {"data": [1.0, 500, 1500, "Sports and outdoor play"], "isController": false}, {"data": [0.6388888888888888, 500, 1500, "Sign Up"], "isController": false}, {"data": [1.0, 500, 1500, "Daraz woman muslim wear"], "isController": false}, {"data": [1.0, 500, 1500, "Fragrances"], "isController": false}, {"data": [1.0, 500, 1500, "Baby health care"], "isController": false}, {"data": [1.0, 500, 1500, "Baby diapers"], "isController": false}, {"data": [1.0, 500, 1500, "Baby gear"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4370, 0, 0.0, 255.31029748283714, 54, 11072, 61.0, 304.0, 486.4499999999998, 5966.909999999997, 134.3871086782705, 1525.0150517597945, 18.37939396065256], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Men shoes", 90, 0, 0.0, 83.58888888888889, 54, 530, 59.0, 84.30000000000004, 328.5500000000007, 530.0, 8.212428141253765, 14.377630543388996, 1.0345734670134137], "isController": false}, {"data": ["Kids toys", 90, 0, 0.0, 66.85555555555555, 55, 443, 59.5, 75.0, 89.80000000000001, 443.0, 8.072472867521752, 14.13786410216163, 1.0169423827249082], "isController": false}, {"data": ["Daraz woman clothing", 90, 0, 0.0, 77.68888888888888, 55, 375, 65.0, 94.9, 104.45, 375.0, 7.800988125162521, 14.28809888835919, 1.1122502600329374], "isController": false}, {"data": ["Baby toddler toys", 90, 0, 0.0, 64.1222222222222, 55, 222, 59.0, 77.9, 84.45, 222.0, 8.074645612775884, 14.576417548896464, 1.1118408509779292], "isController": false}, {"data": ["Daraz home page", 90, 0, 0.0, 725.6444444444444, 262, 1803, 485.0, 1528.9, 1590.15, 1803.0, 3.1884366032522053, 5.396020709338576, 0.36741749920289085], "isController": false}, {"data": ["Hair care", 90, 0, 0.0, 69.8, 54, 188, 61.0, 90.80000000000001, 109.05000000000003, 188.0, 8.022105356983689, 14.295120164453161, 1.0576017804617168], "isController": false}, {"data": ["Kids bag", 90, 0, 0.0, 69.84444444444446, 54, 461, 60.0, 85.70000000000002, 88.45, 461.0, 8.151435558373336, 14.313835929716511, 1.0348502173716148], "isController": false}, {"data": ["Men accessories", 90, 0, 0.0, 64.26666666666668, 55, 139, 60.0, 74.80000000000001, 82.35000000000001, 139.0, 8.034279592929833, 14.275492099625067, 1.0513608061060524], "isController": false}, {"data": ["Men bags", 90, 0, 0.0, 69.52222222222223, 54, 372, 59.5, 76.0, 89.55000000000005, 372.0, 8.118347465271514, 14.179624075410427, 1.0147934331589392], "isController": false}, {"data": ["Men eyewear", 90, 0, 0.0, 67.64444444444443, 55, 358, 61.0, 75.9, 81.35000000000001, 358.0, 8.026397930972978, 14.102631989654865, 1.0268145790600196], "isController": false}, {"data": ["Kids watches", 90, 0, 0.0, 71.61111111111109, 54, 199, 60.0, 88.50000000000003, 190.9, 199.0, 8.148483476686284, 14.497510185604346, 1.0742629583521957], "isController": false}, {"data": ["Men's Care", 90, 0, 0.0, 64.64444444444442, 54, 120, 62.0, 77.9, 85.25000000000001, 120.0, 8.147008237530551, 14.365997273015298, 1.0502002806191726], "isController": false}, {"data": ["Baby personal care", 90, 0, 0.0, 68.24444444444443, 55, 376, 60.0, 72.0, 82.75000000000004, 376.0, 8.057296329453894, 14.40084349820949, 1.0779781222023277], "isController": false}, {"data": ["Traditional game", 90, 0, 0.0, 66.18888888888884, 54, 218, 60.0, 78.0, 118.65000000000005, 218.0, 7.955449482895784, 14.178931317952797, 1.0565831344470962], "isController": false}, {"data": ["Daraz woman bags", 90, 0, 0.0, 81.36666666666667, 55, 465, 62.0, 87.80000000000001, 205.75000000000006, 465.0, 7.970244420828906, 13.970759165781084, 1.0118474362380447], "isController": false}, {"data": ["Login", 90, 0, 0.0, 2002.6333333333328, 55, 9662, 67.0, 6582.600000000002, 7338.450000000001, 9662.0, 3.760026737967914, 450.5159510648187, 0.4810190455798797], "isController": false}, {"data": ["User profile", 90, 0, 0.0, 1500.8666666666668, 55, 9167, 64.0, 5615.400000000001, 6512.550000000001, 9167.0, 4.723169771713461, 474.0980057727631, 0.8697069338756233], "isController": false}, {"data": ["Maternity care", 90, 0, 0.0, 68.81111111111113, 54, 461, 60.0, 76.80000000000001, 101.35000000000001, 461.0, 8.069577692100781, 14.548355823545235, 1.1032625750919034], "isController": false}, {"data": ["Sunglasses", 90, 0, 0.0, 74.13333333333334, 54, 446, 61.5, 79.9, 191.60000000000002, 446.0, 8.178844056706653, 14.308184807797165, 1.0303426594874592], "isController": false}, {"data": ["Add to Cart-1", 90, 0, 0.0, 249.1666666666668, 54, 5325, 63.5, 92.0, 1388.3500000000058, 5325.0, 6.189821182943604, 108.70806288686383, 1.1364124828060522], "isController": false}, {"data": ["Add to Cart-0", 90, 0, 0.0, 400.53333333333325, 274, 1361, 336.0, 534.2, 752.6, 1361.0, 5.929634998023455, 6.822297280603505, 0.7180417380419027], "isController": false}, {"data": ["User profile-1", 25, 0, 0.0, 5131.520000000001, 2949, 9084, 4775.0, 7025.0, 8486.999999999998, 9084.0, 2.301601914932793, 818.601942264316, 0.44953162401031116], "isController": false}, {"data": ["Mens jewellery", 90, 0, 0.0, 71.44444444444441, 54, 245, 60.0, 85.40000000000003, 190.50000000000003, 245.0, 8.168451624614267, 14.447948811036484, 1.0609414707750953], "isController": false}, {"data": ["User profile-0", 25, 0, 0.0, 99.11999999999998, 61, 366, 85.0, 120.80000000000005, 297.29999999999984, 366.0, 3.2022543870885105, 2.83462057288331, 0.4159178061355194], "isController": false}, {"data": ["Baby feeding", 90, 0, 0.0, 74.59999999999998, 54, 451, 60.0, 84.80000000000001, 199.70000000000002, 451.0, 8.056575060424313, 13.98614786612658, 0.991336384388148], "isController": false}, {"data": ["Men watches", 90, 0, 0.0, 65.08888888888889, 54, 245, 59.0, 79.0, 84.35000000000001, 245.0, 8.130081300813009, 14.302803184281842, 1.0400787601626016], "isController": false}, {"data": ["Daraz woman western wear", 90, 0, 0.0, 89.85555555555553, 55, 480, 63.0, 95.0, 446.70000000000005, 480.0, 7.82336578581363, 13.882908933849096, 1.0237607571279554], "isController": false}, {"data": ["Women jewellery", 90, 0, 0.0, 80.09999999999998, 55, 584, 61.0, 99.50000000000003, 204.55000000000007, 584.0, 8.154389779831476, 14.70391495650992, 1.1148579777113345], "isController": false}, {"data": ["Personal Care", 90, 0, 0.0, 68.35555555555555, 55, 448, 60.5, 75.70000000000002, 83.25000000000001, 448.0, 8.139640047029031, 14.36943226010672, 1.0492504748123361], "isController": false}, {"data": ["Luggage bag", 90, 0, 0.0, 70.49999999999997, 54, 466, 60.0, 90.70000000000002, 108.35000000000001, 466.0, 8.075370121130552, 14.213387449528938, 1.0330795760430687], "isController": false}, {"data": ["Men clothing", 90, 0, 0.0, 70.76666666666668, 55, 444, 60.5, 87.10000000000005, 96.35000000000001, 444.0, 8.188517878264033, 14.44239178646165, 1.0555511327449731], "isController": false}, {"data": ["Remote control toys and vehicles", 90, 0, 0.0, 69.9222222222222, 54, 448, 59.0, 74.9, 107.35000000000012, 448.0, 7.975895072669267, 14.921051101116625, 1.207288804945055], "isController": false}, {"data": ["Women makeup", 90, 0, 0.0, 75.96666666666667, 54, 369, 62.5, 100.80000000000001, 136.0, 369.0, 8.075370121130552, 14.265435733512787, 1.048851783310902], "isController": false}, {"data": ["Laptop bag", 90, 0, 0.0, 76.32222222222225, 55, 526, 61.0, 91.9, 130.35000000000014, 526.0, 8.172160174339417, 14.267229637700899, 1.0295006469626804], "isController": false}, {"data": ["Skin care", 90, 0, 0.0, 73.1, 55, 257, 62.0, 104.0, 132.0, 257.0, 7.990056818181818, 14.195875688032672, 1.0455738414417615], "isController": false}, {"data": ["Travels", 90, 0, 0.0, 78.93333333333335, 55, 464, 59.5, 85.9, 206.90000000000006, 464.0, 8.097894547417672, 14.042149822296203, 0.9964206181392837], "isController": false}, {"data": ["Baby nursery", 90, 0, 0.0, 68.22222222222223, 54, 445, 61.0, 77.9, 87.60000000000002, 445.0, 8.063793566884689, 14.515353406952782, 1.094596978317355], "isController": false}, {"data": ["Beauty Tools", 90, 0, 0.0, 74.95555555555553, 54, 383, 61.0, 90.9, 181.45000000000005, 383.0, 8.12274368231047, 14.585507389440433, 1.0946666290613718], "isController": false}, {"data": ["Bath & Body", 90, 0, 0.0, 65.75555555555553, 54, 261, 62.0, 74.9, 82.45, 261.0, 8.130081300813009, 14.186886009485095, 1.0162601626016259], "isController": false}, {"data": ["Add to Cart", 90, 0, 0.0, 650.0111111111112, 341, 6023, 399.5, 805.9, 2335.650000000008, 6023.0, 5.906286914293214, 110.52395737629611, 1.7995717941987137], "isController": false}, {"data": ["Daraz woman watches", 90, 0, 0.0, 80.88888888888889, 54, 527, 63.0, 103.9, 193.0, 527.0, 7.986511669180938, 14.15422009495075, 1.0373105976572898], "isController": false}, {"data": ["Men muslim wear", 90, 0, 0.0, 62.02222222222222, 54, 89, 60.0, 70.9, 81.15000000000002, 89.0, 8.222932846048424, 14.587675593878483, 1.076047852900868], "isController": false}, {"data": ["Daraz woman shoes", 90, 0, 0.0, 81.16666666666666, 54, 444, 63.0, 95.80000000000001, 190.25, 444.0, 7.834943849569079, 13.788685035257247, 1.002321918255419], "isController": false}, {"data": ["Sports and outdoor play", 90, 0, 0.0, 66.57777777777781, 54, 193, 59.0, 79.0, 109.25000000000013, 193.0, 7.970950314409707, 14.38663122176955, 1.0975624944646178], "isController": false}, {"data": ["Sign Up", 90, 0, 0.0, 2481.5555555555547, 254, 11072, 363.5, 7790.7, 8238.85, 11072.0, 3.331359194551377, 399.23686715742525, 0.4359395820994966], "isController": false}, {"data": ["Daraz woman muslim wear", 90, 0, 0.0, 68.19999999999999, 54, 206, 61.0, 88.80000000000001, 103.70000000000002, 206.0, 7.814535035165408, 14.204545454545455, 1.0912876074498568], "isController": false}, {"data": ["Fragrances", 90, 0, 0.0, 76.19999999999999, 55, 447, 61.0, 84.9, 173.90000000000018, 447.0, 8.10883863411118, 14.193107205604107, 1.021523616992522], "isController": false}, {"data": ["Baby health care", 90, 0, 0.0, 65.76666666666668, 55, 200, 60.0, 79.80000000000001, 101.25000000000007, 200.0, 8.071748878923767, 14.698885930493272, 1.1350896860986546], "isController": false}, {"data": ["Baby diapers", 90, 0, 0.0, 66.3, 55, 216, 60.0, 80.70000000000002, 95.30000000000004, 216.0, 8.053691275167786, 14.683829697986576, 1.1482802013422817], "isController": false}, {"data": ["Baby gear", 90, 0, 0.0, 64.02222222222224, 54, 127, 61.0, 76.9, 84.15000000000002, 127.0, 8.05513290969301, 14.055053197440257, 1.0068916137116262], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4370, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
